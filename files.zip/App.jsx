import SidebarInmobiliario from './components/SidebarInmobiliario'

export default function App() {
  return <SidebarInmobiliario />
}
